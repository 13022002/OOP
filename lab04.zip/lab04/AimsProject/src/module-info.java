/**
 * 
 */
/**
 * @author Admin
 *
 */
module AimsProject {
}