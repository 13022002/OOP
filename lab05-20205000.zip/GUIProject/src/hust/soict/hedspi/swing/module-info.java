/**
 * 
 */
/**
 * @author TTMT
 *
 */
module GUIProject {
	requires java.desktop;
}